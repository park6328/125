package com.spring.login;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.login.dao.UDao;
import com.spring.login.dto.UDto;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	/* 
	 * mybatis �� ���� ����Դϴ�.
		src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml bean�� ���� ������ �ֽ��ϴ�.
	*/
	@Autowired
	SqlSession sqlSession;	
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale); 
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "index";
	}
	@RequestMapping(value="/index")
	public String index() {
		logger.info("index()");
		return "index";
	}
	@RequestMapping(value="/loginForm")
	public String loginForm() {
		logger.info("loginForm()");
		return "login";
	}
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String login(HttpServletRequest request) {
		logger.info("login()");
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		String pwChk;
		UDao dao = sqlSession.getMapper(UDao.class);
		pwChk = dao.login(id);
		
		HttpSession session = request.getSession();
		if(pwChk != null) { 
			if(pw.equals(pwChk)) { // �α��� ����
				session.setAttribute("id", id);
				return "index";
			} else { // ��й�ȣ Ʋ��
				return "login";
			}
			
		} else { // ���̵� ����
			return "login";
		}
	}
	@RequestMapping(value="/logout")
	public String logout(HttpServletRequest request) {
		logger.info("logout()");
		
		HttpSession session = request.getSession();
		if (session.getAttribute("id") != null) {
			session.removeAttribute("id");
		}
		return "index";
	}
	@RequestMapping(value="/joinForm")
	public String joinForm() {
		logger.info("joinForm()");
		return "join";
	}
	@RequestMapping(value="/join", method=RequestMethod.POST)
	public String join(UDto dto) {
		logger.info("join()");
		
		UDao dao = sqlSession.getMapper(UDao.class);
		dao.join(dto);
		
		return "index";
	}
}
