package com.spring.login.dao;

import com.spring.login.dto.UDto;


public interface UDao {
	public String login(String id);
	public void join(UDto dto);
}


