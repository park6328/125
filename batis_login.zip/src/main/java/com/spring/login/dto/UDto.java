package com.spring.login.dto;

/* ����Ŭ �����ͺ��̽� sql ��

-- ���̺� ����
create table login (
num number(10) primary key,
id varchar2(20) not null,
pw varchar2(20) not null,
name varchar2(20) not null,
age number(4) not null,
email varchar2(50) not null
);

-- ������ ����
create SEQUENCE login_seq;

-- admin 1111 ���
insert into login values(login_seq.nextval, 'admin', '1111', 'admin', 30, 'admin@google.com');

commit;

-- ���̵� ��� Ȯ��
select * from login;

*/

public class UDto {
	private int num;
	private String id;
	private String pw;
	private String name;
	private String age;
	private String email;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
