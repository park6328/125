package edu.bit.ex;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.bit.ex.service.SingUPService;
import edu.bit.ex.vo.MemberVO;

/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping("/member/*")
public class MemberController {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	 @Inject
	 SingUPService service;
	 
	 @Inject
	 BCryptPasswordEncoder passEncoder;
	 
	 @RequestMapping(value = "/register", method = RequestMethod.GET)
	 public void getRegister() throws Exception {
	  logger.info("get register");
	 }

	 
	 @RequestMapping(value = "/register", method = RequestMethod.POST)
	 public String postRegister(MemberVO vo) throws Exception {
	  logger.info("post resister");
	  System.out.println("�������");
	  
	  String password = vo.getPassword();
	  String encode = passEncoder.encode(password);
	  
	  System.out.println(password);
	  System.out.println(encode);
	  
	  vo.setPassword(encode);
	  
	  service.insertMember(vo);
	  
	  return "redirect:/";
	 }
	 
}
