package edu.bit.ex.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.bit.ex.vo.MemberVO;
import edu.bit.mapper.SignUPMapper;

@Service
public class SingUPService {
	
	@Inject
	SignUPMapper signUPMapper;
	
	@Transactional
    public void insertMember(MemberVO memVO) throws Exception {
    	signUPMapper.insertMember(memVO);
    	signUPMapper.insertAuthorities(memVO);
    }
}
