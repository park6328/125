package edu.bit.mapper;

import org.apache.ibatis.annotations.Insert;

import edu.bit.ex.vo.MemberVO;

public interface SignUPMapper {

	@Insert("insert into users (username,password) values(#{username},#{password})")
	public void insertMember(MemberVO memVO);
	
	@Insert("insert into AUTHORITIES (username,AUTHORITY) values(#{username},'ROLE_USER')")
	public void insertAuthorities(MemberVO memVO);
}
