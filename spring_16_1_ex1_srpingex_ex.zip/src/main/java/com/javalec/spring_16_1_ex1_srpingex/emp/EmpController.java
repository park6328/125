package com.javalec.spring_16_1_ex1_srpingex.emp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.javalec.spring_16_1_ex1_srpingex.command.BCommand;
import com.javalec.spring_16_1_ex1_srpingex.command.BContentCommand;
import com.javalec.spring_16_1_ex1_srpingex.command.BDeleteCommand;
import com.javalec.spring_16_1_ex1_srpingex.command.BListCommand;
import com.javalec.spring_16_1_ex1_srpingex.command.BModifyCommand;
import com.javalec.spring_16_1_ex1_srpingex.command.BReplyCommand;
import com.javalec.spring_16_1_ex1_srpingex.command.BReplyViewCommand;
import com.javalec.spring_16_1_ex1_srpingex.command.BWriteCommand;

/**
 * Servlet implementation class BoardFrontController
 */

@Controller
public class EmpController {

	@RequestMapping("/login")
	public String list(HttpServletRequest req ,Model model) {
		System.out.println("login()");
		
		String name = req.getParameter("name");
		String number = req.getParameter("number");
		
	
		String result_number;
		EmpDao empDao = new EmpDao();
		result_number = empDao.login(name);
		
		if(result_number != null) 
		{ 
			if(result_number.equals(number)) { // �α��� ����
				model.addAttribute("user", name);
				return "emp/index";
			} else { // ��й�ȣ Ʋ��
				return "emp/login";
			}
			
		} else { // ���̵� ����
			return "emp/login";
		}	
		
	}	
	
}
