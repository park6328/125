package edu.bit.ex.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.bit.ex.command.BCommand;
import edu.bit.ex.command.BContentCommand;
import edu.bit.ex.command.BDeleteCommand;
import edu.bit.ex.command.BListCommand;
import edu.bit.ex.command.BModifyCommand;
import edu.bit.ex.command.BReplyCommand;
import edu.bit.ex.command.BReplyViewCommand;
import edu.bit.ex.command.BWriteCommand;
import edu.bit.ex.dao.IBDao;
import edu.bit.ex.dto.BDto;
import edu.bit.ex.page.Criteria;
import edu.bit.ex.page.PageMaker;

/**
 * Servlet implementation class BoardFrontController
 */

@Controller
public class BController {

	@Inject
	SqlSession sqlSession;	
	
	BCommand command = null;
	
	@RequestMapping("/list")
	public String list(Model model) {
		System.out.println("list()");

		IBDao dao = sqlSession.getMapper(IBDao.class);
		model.addAttribute("list", dao.list());
			
		return "list";
	}
	
	@RequestMapping("/write_view")
	public String write_view(Model model) {
		System.out.println("write_view()");
		
		return "write_view";
	}
	
	@RequestMapping("/write")
	public String write(HttpServletRequest request, Model model) {
		System.out.println("write()");
		
		model.addAttribute("request", request);
		command = new BWriteCommand();
		command.execute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request, Model model){
		System.out.println("content_view()");
		
		model.addAttribute("request", request);
		command = new BContentCommand();
		command.execute(model);
		
		return "content_view";
	}
	
	@RequestMapping(value="/modify", method=RequestMethod.POST )
	public String modify(HttpServletRequest request, Model model){
		System.out.println("modify()");
		
		model.addAttribute("request", request);
		command = new BModifyCommand();
		command.execute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping("/reply_view")
	public String reply_view(HttpServletRequest request, Model model){
		System.out.println("reply_view()");
		
		model.addAttribute("request", request);
		command = new BReplyViewCommand();
		command.execute(model);
		
		return "reply_view";
	}
	
	@RequestMapping("/reply")
	public String reply(HttpServletRequest request, Model model) {
		System.out.println("reply()");
		
		model.addAttribute("request", request);		
		command = new BReplyCommand();
		command.execute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		System.out.println("delete()");
		
		model.addAttribute("request", request);
		command = new BDeleteCommand();
		command.execute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping("/list2")
	public void list2(Criteria cri, Model model) {
		System.out.println("blist()");
		
		IBDao dao = sqlSession.getMapper(IBDao.class);
		

		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		
		System.out.println(cri.getPerPageNum());
		System.out.println(cri.getPage());
		
		//��ü �Խù� ���� ����
	    int totalCount = dao.total() ;
		pageMaker.setTotalCount(totalCount);
		
        //�𵨿� �߰�
		List<BDto> boards = dao.listPage(cri);
		
		
		model.addAttribute("list", boards);
		model.addAttribute("pageMaker", pageMaker);

		//return "redirect:list";
	}
	
}
