package edu.bit.ex.dao;

import java.util.ArrayList;

import edu.bit.ex.dto.BDto;
import edu.bit.ex.page.Criteria;

public interface IBDao {
	
	 ArrayList<BDto> list();
	 void writeDao(String mWriter, String mContent);
	 int total();
	 ArrayList<BDto> listPage(Criteria criteria);
	
}