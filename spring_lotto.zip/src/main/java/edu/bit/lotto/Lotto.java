package edu.bit.lotto;

import java.util.HashSet;

public class Lotto {
	
	HashSet<Integer> set;

	public HashSet<Integer> getSet() {
		
		set = new HashSet<Integer>();
		
		while (set.size() < 6) {
			set.add((int) (Math.random() * 45) + 1);
		}		
		return set;
	}

	public void setSet(HashSet<Integer> set) {
		this.set = set;
	}
}
